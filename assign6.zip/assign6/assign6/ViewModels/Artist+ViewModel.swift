//
//  Artist+ViewModel.swift
//  assign6
//
//  Created by Leo Lopez and Dale Westberg on 5/4/22.
//

import Foundation

extension Artist {
    var showName: String {
        return name ?? "Undefined"
    }
}
